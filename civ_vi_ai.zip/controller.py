class Controller:
    def __init__(self):
        self.players