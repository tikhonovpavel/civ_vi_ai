class Nations:
    COLORS = {'Rome': (0, 0, 255),
              'Egypt': (0, 255, 0),
              'Babylon': (255, 0, 0)}
